//
//  Meme.swift
//  meme1
//
//  Created by Evan Scharfer on 12/4/15.
//  Copyright © 2015 Evan Scharfer. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    var topText : String
    var bottomText : String
    var originalImage : UIImage
    var memedImage : UIImage
    
}
